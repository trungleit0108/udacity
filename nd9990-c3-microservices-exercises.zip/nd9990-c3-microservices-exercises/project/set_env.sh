# This file is used for convenience of local development.
# DO NOT STORE YOUR CREDENTIALS INTO GIT
export POSTGRES_USERNAME=postgres
export POSTGRES_PASSWORD=password1
export POSTGRES_HOST=udagram2.csixzufepzrt.us-west-2.rds.amazonaws.com
export POSTGRES_DB=udagram
export AWS_BUCKET=arn:aws:s3:::udaconnect
export AWS_REGION=us-west-2
export AWS_PROFILE=test
export JWT_SECRET=testing
export URL=http://localhost:8100
